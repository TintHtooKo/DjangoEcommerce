from django.contrib import admin
from projectApp.models import Category,Product,Order,ContentUs

admin.site.register(Category),
admin.site.register(Product),
admin.site.register(Order),
admin.site.register(ContentUs)
