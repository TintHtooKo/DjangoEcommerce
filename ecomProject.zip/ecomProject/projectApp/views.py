from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from projectApp.models import Category,Product,Cart,Order,ContentUs
from datetime import datetime
import os

def Home(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    return render(request, 'home.html',{'count':count})

def About(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    return render(request,'about.html',{'count':count})

def Content(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    if request.method == "POST":
        content = ContentUs.objects.create(
            name = request.POST.get('name'),
            email = request.POST.get('email'),
            phone = request.POST.get('phone'),
            message = request.POST.get('msg')           
        )
        content.save()
        messages.success(request, "Thanks for content us.")
    return render(request,'content.html',{'count':count})

def Register(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('pass1')
        pass2 = request.POST.get('pass2')
        if pass1 != pass2:
            messages.error(request,'Password does not match!!!')
        elif len(pass1)<6:
            messages.error(request,'Password must be greater than 6!!!')
        elif len(uname)<6:
            messages.error(request,'Username must be greater than 6!!!')
        elif User.objects.filter(username=uname).exists():
            messages.error(request, 'Username already exists')
        elif User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
        else:
            my_user = User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')
    return render(request,'register.html',{'count':count})
    
    

def Login(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    if request.method=='POST':
        uname = request.POST.get('username')
        pass1 = request.POST.get('pass1')
        user = authenticate(request,username=uname,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('shop')
        else:
            messages.error(request,'Username Or Password does not match!')
    return render(request,'login.html',{'count':count})

def Shop(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    product = Product.objects.all()
    return render(request,'shop.html',{'product':product,'count':count})


@login_required(login_url='login')
def CheckOut(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    return render(request,'checkout.html',{'count':count})

def Success(request):
    count = Cart.objects.filter(user_id = request.user.id).count()
    return render(request,'success.html',{'count':count})

def Logout(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def CartCreate(request, pdt_id):
    cart = Cart.objects.create(
        product = Product.objects.get(id=pdt_id),
        qty = 1,
        user_id = request.user.id,
        created_at = datetime.now()
    )
    cart.save()
    return redirect('shop')

@login_required(login_url='login')
def CartList(request,user_id):
        cart = Cart.objects.filter(user_id=user_id)
        count = Cart.objects.filter(user_id=request.user.id).count()
        return render(request, 'cartList.html',{'cart':cart,'count':count})

@login_required(login_url='login')
def CartDelete(request,cart_id):
    cart = Cart.objects.get(id=cart_id)
    cart.delete()
    return redirect(f'/cartList/{request.user.id}')

@login_required(login_url='login')
def CheckOut(request,order_id):
    count = Cart.objects.filter(user_id = request.user.id).count()
    if request.method == 'GET':
        category = Category.objects.all()
        product = Product.objects.get(id=order_id)
        return render(request,'checkout.html',{'count':count,'category':category,'product':product})
    if request.method == 'POST':
        order = Order.objects.create(
            name = request.POST.get('name'),
            email = request.POST.get('email'),
            phone = request.POST.get('phone'),
            address = request.POST.get('address'),
            product = request.POST.get('prod'),
            code = request.POST.get('code'),
            quantity = request.POST.get('qty'),
            price = request.POST.get('price'),
        )

        order.save()
        return redirect('success')

