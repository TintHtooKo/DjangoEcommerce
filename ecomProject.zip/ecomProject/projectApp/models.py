from django.db import models
from django.contrib.auth.models import User

ORDER_CHOICES = [
    ('pending', 'Pending'),
    ('accepted', 'Accepted'),
    ('success', 'Success'),
    ('cancel', 'Cancel'),
]

class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
class Product(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=100)
    image = models.ImageField(default=None)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    price = models.IntegerField(default=None)
    
    def __str__(self):
        return self.code
    
class Cart(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    qty = models.IntegerField()
    user = models.ForeignKey(User,on_delete=models.CASCADE, default=None)
    created_at = models.DateTimeField(default=None)
    
class Order(models.Model):
    
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    address = models.CharField(max_length=1000)
    product = models.CharField(max_length=100)
    quantity = models.CharField(max_length=100)
    price = models.CharField(max_length=100)
    code = models.CharField(max_length=100)
    status = models.CharField(max_length=20,choices=ORDER_CHOICES,default='pending')

    def __str__(self):
        return self.code

class ContentUs(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    phone = models.CharField(max_length=15)
    message = models.CharField(max_length=1000)

    def __str__(self):
        return self.name
