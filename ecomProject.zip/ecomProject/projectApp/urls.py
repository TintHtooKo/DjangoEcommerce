from django.urls import path
from projectApp import views

urlpatterns = [
    path('',views.Home,name='home'),
    path('about/',views.About,name='about'),
    path('content/',views.Content,name='content'),
    path('register/',views.Register,name='register'),
    path('login/',views.Login,name='login'),
    path('shop/',views.Shop,name='shop'),
    path('check/<int:order_id>/',views.CheckOut,name='check'),
    path('success/',views.Success,name='success'),
    path('logout/',views.Logout,name='logout'),
    path('cartCreate/<int:pdt_id>/', views.CartCreate),
    path('cartList/<int:user_id>/', views.CartList),
    path('cartDelete/<int:cart_id>/', views.CartDelete),

]
